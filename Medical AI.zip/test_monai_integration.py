#!/usr/bin/env python3
"""
Test script to verify MONAI integration in MedExpert
"""

import sys
import os
sys.path.append('/home/ubuntu/workspace/medexpert-deploy')

from medical_imaging_enhanced import EnhancedMedicalImageAnalyzer
import json

def test_monai_integration():
    """Test the MONAI integration"""
    print("🔬 Testing MONAI Integration in MedExpert")
    print("=" * 50)
    
    # Initialize the enhanced analyzer
    print("1. Initializing Enhanced Medical Image Analyzer...")
    analyzer = EnhancedMedicalImageAnalyzer()
    
    # Test image path
    test_image_path = "/home/ubuntu/workspace/medexpert-deploy/sample_chest_xray.jpg"
    
    if not os.path.exists(test_image_path):
        print(f"❌ Test image not found at {test_image_path}")
        return False
    
    print(f"2. Testing with image: {test_image_path}")
    
    # Test chest X-ray analysis
    print("\n🩻 Testing Chest X-ray Analysis...")
    try:
        chest_results = analyzer.analyze_chest_xray(test_image_path)
        print("✅ Chest X-ray analysis completed")
        print(f"   - Modality: {chest_results.get('modality', 'Unknown')}")
        print(f"   - Image Quality: {chest_results.get('image_quality', 'Unknown')}")
        print(f"   - Findings: {len(chest_results.get('pathological_findings', []))} detected")
        print(f"   - Impression: {chest_results.get('impression', 'No impression')}")
    except Exception as e:
        print(f"❌ Chest X-ray analysis failed: {e}")
        return False
    
    # Test anatomical segmentation
    print("\n🧩 Testing Anatomical Segmentation...")
    try:
        seg_results = analyzer.segment_anatomical_structures(test_image_path, "Chest X-ray")
        print("✅ Anatomical segmentation completed")
        print(f"   - Structures identified: {len(seg_results.get('structures_identified', []))}")
        print(f"   - Volumes calculated: {len(seg_results.get('volumes', {}))}")
    except Exception as e:
        print(f"❌ Anatomical segmentation failed: {e}")
        return False
    
    # Test abnormality detection
    print("\n🔍 Testing Abnormality Detection...")
    try:
        abn_results = analyzer.detect_abnormalities(test_image_path, "Chest X-ray", "Routine screening")
        print("✅ Abnormality detection completed")
        print(f"   - Abnormalities detected: {len(abn_results.get('abnormalities_detected', []))}")
        print(f"   - Normal findings: {len(abn_results.get('normal_findings', []))}")
        print(f"   - AI Model: {abn_results.get('ai_model_version', 'Unknown')}")
    except Exception as e:
        print(f"❌ Abnormality detection failed: {e}")
        return False
    
    # Test image preprocessing
    print("\n🔧 Testing Image Preprocessing...")
    try:
        preprocessed = analyzer.preprocess_image(test_image_path, "Chest X-ray")
        print("✅ Image preprocessing completed")
        print(f"   - Preprocessed shape: {preprocessed.shape}")
        print(f"   - Data type: {preprocessed.dtype}")
        print(f"   - Value range: [{preprocessed.min():.3f}, {preprocessed.max():.3f}]")
    except Exception as e:
        print(f"❌ Image preprocessing failed: {e}")
        return False
    
    print("\n" + "=" * 50)
    print("🎉 All MONAI integration tests passed!")
    print("✅ MedExpert is successfully enhanced with MONAI framework")
    
    # Save detailed results
    test_results = {
        "chest_xray_analysis": chest_results,
        "segmentation_results": seg_results,
        "abnormality_detection": abn_results,
        "preprocessing_info": {
            "shape": list(preprocessed.shape),
            "dtype": str(preprocessed.dtype),
            "min_value": float(preprocessed.min()),
            "max_value": float(preprocessed.max())
        }
    }
    
    with open('/home/ubuntu/workspace/monai_test_results.json', 'w') as f:
        json.dump(test_results, f, indent=2, default=str)
    
    print(f"📄 Detailed results saved to: /home/ubuntu/workspace/monai_test_results.json")
    
    return True

if __name__ == "__main__":
    success = test_monai_integration()
    sys.exit(0 if success else 1)

